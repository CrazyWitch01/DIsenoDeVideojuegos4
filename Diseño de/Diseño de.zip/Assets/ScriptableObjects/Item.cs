using UnityEngine;

public class Item : MonoBehaviour
{
    [SerializeField] ItemData itemData;
}
