using UnityEngine;

public class Cuarto : MonoBehaviour
{
    //name Text
    //shape cuarto sprite

    public string NombreCuarto;
    public Sprite FormaCuarto;
    public Vector3 PosicionCuarto;
    public TIPOS_CUARTO Tipo_actual;
}
