using UnityEngine;

public class Mundo : MonoBehaviour
{
    public string NombreMundo;
    public Cuarto[] Cuartos;
}
